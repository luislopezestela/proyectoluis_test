<?php
$dat = new DatosAdmin();
$dat->id = $_POST['dat'];
$dat->eliminar_item_de_stock();