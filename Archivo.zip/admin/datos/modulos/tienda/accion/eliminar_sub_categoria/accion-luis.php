<?php
$cat = new DatosAdmin();
$cat->id = $_POST["id"];
$cat->eliminar_sub_categoria();