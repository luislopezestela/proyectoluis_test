<?php

$data = new DatosAdmin();
$data->id = $_POST["dat"];
$data->delete_option_type();