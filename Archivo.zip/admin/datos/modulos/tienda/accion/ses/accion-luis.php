<?php
unset($_SESSION['admin_id']);
$_SESSION['adios_user']=1;