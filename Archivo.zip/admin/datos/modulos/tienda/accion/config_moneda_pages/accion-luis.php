<?php
$dt = new DatosAdmin();
$dt->actualizar_moneda_none();
$dt->actualizar_moneda_page($_POST['moneda']);
?>
