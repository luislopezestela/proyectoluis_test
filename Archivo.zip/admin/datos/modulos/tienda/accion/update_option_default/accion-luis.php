<?php
DatosAdmin::options_noes_principal($_POST['typs']);
DatosAdmin::options_aser_principal($_POST['opt_ops']);
