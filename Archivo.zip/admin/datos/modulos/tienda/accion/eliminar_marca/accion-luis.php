<?php 
$m = new DatosAdmin();
$m->id = $_POST['id'];
$m->eliminar_marca();