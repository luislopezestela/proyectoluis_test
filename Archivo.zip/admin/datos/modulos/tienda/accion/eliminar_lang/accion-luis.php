<?php
$lang = new DatosLang();
$lang->columna = $_POST['langs'];
$lang->eliminar_language_file();