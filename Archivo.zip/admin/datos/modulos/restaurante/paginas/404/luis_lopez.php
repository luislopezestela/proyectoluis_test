<b>ERROR 404, pagina <?php 
if (isset($_GET["paginas"])) {
	print($_GET["paginas"]);
}
 ?></b> no encontrado!!