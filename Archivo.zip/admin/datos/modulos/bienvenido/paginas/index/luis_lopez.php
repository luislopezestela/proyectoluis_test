<div class="contenido_dark">
  <div class="text"><?=Luis::lang("bienvenido");?></div>
  <div class="select_language">
    <p class="alert_message_display"><?=Luis::lang("todos_los_datos_estan_protegidos_los_datos_seran_verificados_en_tiempo_real_verificacion_de_identidad");?></p>
    <h3 class="alert_message_display_rep"><?=Luis::lang("los_datos_falsos_seran_verificados_y_reportados");?></h3>
    <br>
    <div class="btn btn__secondary start_page_data"><p><?=Luis::lang("iniciar");?></p></div>
  </div>
</div>